# coding: utf-8

from django.shortcuts import render
from datetime import datetime, timedelta

def index_view(request):
    context = {}
    return render(request, 'index.html', context)

def wynik_view(request):
    context = {}
    
    if request.method != 'POST':
        context['error'] = 'Bezpośredni dostęp jest zabroniony!'
    else:
        wzrost = int(request.POST.get('wzrost', '0'))
        waga = int(request.POST.get('waga', '0'))
        wiek = int(request.POST.get('wiek', '0'))
        plec = int(request.POST.get('plec', '0'))
        starttime = request.POST.get('starttime', '00:00')
        endtime = request.POST.get('endtime', '00:00')
        
        plecNazwa = 'MĘŻCZYZNA' if plec == 1 else 'KOBIETA'
        
        TBWM = 2.447 - (0.09156 * wiek) + (0.1074 * wzrost) + (0.3362 * waga)
        TBWK = -2.097 + (0.1069 * wzrost) + (0.2466 * waga)
        
        promile = 0
        
        for i in range(1, 5):
            if request.POST.get('ilosc' + str(i)) is None:
                continue
            
            iloscI = int(request.POST.get('ilosc' + str(i), '0'))
            procentI = float(request.POST.get('procent' + str(i), '0'))
            numberdrinkI = int(request.POST.get('numberdrink' + str(i), '0'))
            wartosc = iloscI * (procentI / 100) * 0.79
            promile += wartosc * numberdrinkI
        
        dataStart = datetime.strptime(starttime, '%H:%M')
        dataKoniec = datetime.strptime(endtime, '%H:%M')
        trwaloGodzin = dataKoniec - dataStart
        trwaloGodzinInt = trwaloGodzin.seconds // 3600
        
        if plec == 1:
            ilePromila = (promile / TBWM) * 0.8 - (trwaloGodzinInt * 0.15)
        else:
            ilePromila = (promile / TBWK) * 0.8 - (trwaloGodzinInt * 0.15)
        
        ilePromila = 0 if ilePromila < 0 else round(ilePromila, 2)

        ileGodzinDo = 0
        
        ilePromilaI = ilePromila
        
        while ilePromilaI > 0.1:
            ileGodzinDo += 1
            ilePromilaI -= 0.15
        
        godzinaWytrzezwienia = dataKoniec + timedelta(hours=ileGodzinDo)
        
        context.update({
            'plecNazwa': plecNazwa,
            'godzinaRozpoczecia': dataStart.strftime('%H:%M'),
            'trwaloGodzinInt': trwaloGodzinInt,
            'ilePromila': ilePromila,
            'ileGodzinDo': ileGodzinDo,
            'godzinaWytrzezwienia': godzinaWytrzezwienia.strftime('%H:%M'),
        })
    
    return render(request, 'oblicz.html', context)
