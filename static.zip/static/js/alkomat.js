
var alkomatLiczbaWierszy = 1;
var alkomatNazwyIlosci = ['jedno', 'dwa', 'trzy', 'cztery', 'pięć', 'sześć', 'siedem', 'osiem', 'dziewięć'];

$(document).ready(function(){
    $('#alkomat-form').submit(ZapiszFormularz);

	$('input[name=starttime]').datetimepicker({
		datepicker: false,
		format: 'H:i',
		defaultTime: '00:00'
	});
	
	$('input[name=endtime]').datetimepicker({
		datepicker: false,
		format: 'H:i',
		defaultTime: '00:00'
	});

	UzupelnijNumberDrink(1);

	WczytajFormularz();

	$('#alkomat-body').fadeIn(1000);
});

function UsunCiasteczka() {
    var cookies = $.cookie();
    for (var cookie in cookies)
        if (cookie.startsWith('form_'))
            $.removeCookie(cookie);
}

function LoadFormValue(item) {
    return $.cookie('form_' + item);
}

function LoadFormInputValue(item) {
    $('input[name=' + item + ']').val(LoadFormValue(item));
}

function LoadFormSelectValue(item) {
    var value = LoadFormValue(item);
    if (value == null || value == '')
        $('select[name=' + item + ']').val('0');
    else
        $('select[name=' + item + ']').val(value);
}

function LoadFormRadioValue(item) {
    var value = LoadFormValue(item);
    $('input[name=' + item + '][value=\'' + value + '\']').prop("checked", true);
}

function SaveFormValue(item, value) {
    $.cookie('form_' + item, value);
}

function SaveFormInputValue(item) {
    SaveFormValue(item, $('input[name=' + item + ']').val());
}

function SaveFormSelectValue(item) {
    SaveFormValue(item, $('select[name=' + item + ']').val());
}

function SaveFormRadioValue(item) {
    SaveFormValue(item, $('input[name=' + item + ']:checked').val());
}

function WczytajFormularz() {
    var liczbaWierszy = LoadFormValue('iloscwierszy');

    while (alkomatLiczbaWierszy > 1)
        AlkomatUsunWiersz();
    while (alkomatLiczbaWierszy < liczbaWierszy)
        AlkomatDodajWiersz();

    LoadFormRadioValue('plec');
    LoadFormInputValue('wzrost');
    LoadFormInputValue('waga');
    LoadFormInputValue('wiek');
    LoadFormInputValue('starttime');
    LoadFormInputValue('endtime');

    for (var i = 1; i <= 5; i++) {
        LoadFormInputValue('ilosc' + i);
        LoadFormInputValue('procent' + i);
        LoadFormSelectValue('numberdrink' + i);
    }
}

function ZapiszFormularz() {
    SaveFormRadioValue('plec');
    SaveFormInputValue('wzrost');
    SaveFormInputValue('waga');
    SaveFormInputValue('wiek');
    SaveFormInputValue('starttime');
    SaveFormInputValue('endtime');

    for (var i = 1; i <= 5; i++) {
        SaveFormInputValue('ilosc' + i);
        SaveFormInputValue('procent' + i);
        SaveFormSelectValue('numberdrink' + i);
    }

    SaveFormValue('iloscwierszy', alkomatLiczbaWierszy);
}

function UzupelnijNumberDrink(index) {
	$numberDrink = $('select[name=numberdrink' + index + ']');
	for (var i = 1; i <= 9; i++)
		$numberDrink.append(new Option(alkomatNazwyIlosci[i - 1], i));
}

function AlkomatDodajWiersz() {
	if (alkomatLiczbaWierszy >= 5)
		return false;
	
	alkomatLiczbaWierszy += 1;
	
	$nowyWiersz = $('#wiersz1').clone();
	$nowyWiersz.find('input[name=ilosc1]').attr({'name':'ilosc' + alkomatLiczbaWierszy}).val('');
	$nowyWiersz.find('input[name=procent1]').attr({'name':'procent' + alkomatLiczbaWierszy}).val('');
	$nowyWiersz.find('select[name=numberdrink1]').attr({'name':'numberdrink' + alkomatLiczbaWierszy});
	$nowyWiersz.attr({'id':'wiersz' + alkomatLiczbaWierszy});
	
	$('#wiersz' + (alkomatLiczbaWierszy - 1)).after($nowyWiersz);
	
	if (alkomatLiczbaWierszy >= 5)
		$('#dodajWierszBtn').addClass('disabled');
	else
		$('#usunWierszBtn').removeClass('disabled');
}

function AlkomatUsunWiersz() {
	if (alkomatLiczbaWierszy == 1)
		return false;
	
	$('#wiersz' + alkomatLiczbaWierszy).remove();
	
	alkomatLiczbaWierszy -= 1;
	
	if (alkomatLiczbaWierszy == 1)
		$('#usunWierszBtn').addClass('disabled');
	else
		$('#dodajWierszBtn').removeClass('disabled');
}